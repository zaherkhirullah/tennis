CREATE PROCEDURE all_rezervasyons()
  BEGIN
SELECT * FROM tennis_db.rezervasyons;
END;


CREATE PROCEDURE all_korts()
  BEGIN
SELECT * FROM tennis_db.korts;
END;


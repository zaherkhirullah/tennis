CREATE PROCEDURE all_servis()
  BEGIN
SELECT * FROM tennis_db.servis;
END;


CREATE PROCEDURE all_user()
  BEGIN
SELECT kiralayans.id,
kiralayans.isim,
kiralayans.telefon,
users.password,
users.cinsiyet,
users.email,
users.adres,
users.puan,
users.yas
 FROM tennis_db.users,tennis_db.kiralayans 
 where tennis_db.kiralayans.id=tennis_db.users.id;
END;


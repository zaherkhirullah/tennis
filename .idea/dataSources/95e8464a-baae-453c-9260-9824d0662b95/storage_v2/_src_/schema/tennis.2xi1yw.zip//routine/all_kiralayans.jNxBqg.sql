CREATE PROCEDURE all_kiralayans()
  BEGIN
SELECT * FROM tennis_db.kiralayans;
END;


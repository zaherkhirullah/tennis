CREATE PROCEDURE update_korts(IN `_id`          INT(10), IN `_isim` VARCHAR(255), IN `_type` TINYINT,
                              IN `_durum`       TINYINT(1), IN `_created_at` TIMESTAMP, IN `_updated_at` TIMESTAMP,
                              IN `_saat_ucreti` DOUBLE, IN `_saat_puani` DOUBLE)
  BEGIN
SELECT * FROM tennis_db.servis;


UPDATE `tennis_db`.`korts`
SET

`isim` = _isim ,
`type` = _type,
`durum` = _durum,
`created_at` = _created_at,
`updated_at` = _updated_at,
`saat_ucreti` = _saat_ucreti,
`saat_puani` = _saat_puani
WHERE `id` = _id;






END;


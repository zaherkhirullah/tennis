CREATE PROCEDURE rezervasyons_iptal(IN `_id` INT(10), IN `_updated_at` TIMESTAMP)
  BEGIN
SELECT * FROM tennis_db.servis;
UPDATE `tennis_db`.`rezervasyons`
SET
`durum` =0,
`updated_at` = _updated_at
WHERE `id` = _id;

END;

